    function validate(){
            var username =  document.getElementById("username");
            var psd = document.getElementById("loginpass");
            
            function check(callback){
                if (username.value == "admin" && psd.value == "12345"){
                    alert("valid");
                    return true;
                    callback();

                }
                else{
                    alert("invalid");
                    return false;
                }               

            }
                
            function display(){
                location.href = "http://127.0.0.1:5500/main.html?";
                alert("successfull");

            }
            check(display);
        }
        
    $(document).ready(function(){
        $("#input").click(()=>{
            alert("successfull"); 
            location.href = " http://127.0.0.1:5500/todo.html ";

         });
    })

      
    













    