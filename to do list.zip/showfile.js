
document.getElementById("btn").addEventListener("click", btn);


function Todolist(){
    fetch("http://jsonplaceholder.typicode.com/todos")
        .then((res) => { return res.json() })
        .then((data) => {
            let result = `<h2> Jsonplaceholder API</h2>`;
            data.forEach((user) => {
                const { UserId , Id, email,Title } = user
                    `<div>
                        <h5> USER ID: ${UserId} </h5>
                         <ul class="w3-ul">
                             <li> ID : ${Id}</li>
                             <li> TITLE ${Title} </li>
                         </ul>
                    </div>`;
                        document.getElementById('result').innerHTML = result;
                    });
                });
}
